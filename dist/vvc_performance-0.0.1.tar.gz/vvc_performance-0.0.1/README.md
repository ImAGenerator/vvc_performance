# vvc_performance
Performance Analyser Framework to the reference software of Versatile Video Coding (VVC), VVC Test Model (VTM)
