# VVC Performance
Performance Analyser Framework for the reference software of Versatile Video Coding (VVC), VVC Test Model (VTM)

# Installing VVC Performance
## Clone repository
Open terminal and write down this command, making sure that git is installed

```git clone https://github.com/luiseduardomendes/vvc_performance.git```

then enter in the directory using

```cd vvc_performance```

and finally enter

```python3 -m pip install .```

After this the package was installed and can be used.



 
